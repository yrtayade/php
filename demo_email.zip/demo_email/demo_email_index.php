<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<?php
				require 'PHPMailer/PHPMailer.php';
				require 'PHPMailer/SMTP.php';
				require 'PHPMailer/Exception.php';

				$mail = new PHPMailer\PHPMailer\PHPMailer();
				$mail->IsSMTP();
				$mail->SMTPDebug = 1;
				$mail->SMTPAuth = true;
				$mail->SMTPSecure = 'ssl';
				$mail->Host = "smtp.gmail.com";
				$mail->Port = 465;
				$mail->IsHTML(true);
				$mail->Username = "SENDERS_EMAIL_ID";
				$mail->Password = "APP_PASSWORD";

				$mail->SetFrom("SENDERS_EMAIL ID","SENDERS_NAME");

				$mail->Subject = 'YOUR SUBJECT';

				$mail->Body =
				'
					<p> Dear student,  </p>
					<p> Thank you for registration. We will get back to you shortly.</p>
					<p> Thank you</p>

				';


				$mail->AddAddress( "RECEIVERS_EMAIL_ID" );

				if($mail->Send())
				{
					echo "Succeess";
				}
				else
				{
					echo "fail";
				}
		

	?>

</body>
</html>
